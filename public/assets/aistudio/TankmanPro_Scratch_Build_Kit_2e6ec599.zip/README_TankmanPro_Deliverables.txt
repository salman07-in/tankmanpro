TANKMANPRO — PRD AND GOOGLE AI STUDIO BUILD KIT

Core files:
1. TankmanPro_PRD_Google_AI_Studio.md — full product requirements and acceptance criteria.
2. TankmanPro_PRD_Google_AI_Studio.docx — editable Word version.
3. TankmanPro_PRD_Google_AI_Studio.pdf — shareable PDF version.
4. TankmanPro_Google_AI_Studio_Master_Prompt.txt — paste this into a brand-new Google AI Studio Build Mode project after providing the PRD.
5. TankmanPro_AI_Studio_Phased_Prompts.md — staged prompts for building and testing one phase at a time.
6. TankmanPro_Separate_Admin_Vendor_URLs_Prompt.txt — focused prompt if the separate portal URLs need to be applied or re-checked.

Mandatory portal URL requirement:
- Customer storefront: https://tankmanpro.com/
- Main Admin portal: https://admin.tankmanpro.com/login
- Vendor portal: https://partner.tankmanpro.com/login
- AI Studio preview fallbacks before custom DNS is configured: /admin/login and /vendor/login on the preview host.

The public customer website must not display Admin/Vendor portal links or role-switching controls. The portals must use role-protected app shells with one shared backend and authoritative Firestore database. URL separation is not security; enforce role authorization in backend APIs and Firestore rules.

Suggested build order:
- Start a new Google AI Studio Build project.
- Provide the PRD as context and paste the Master Prompt.
- Start with Prompt 0 and Prompt 1; inspect the result and run build/tests.
- Continue with one phased prompt at a time, then run the production-readiness audit.
- Configure custom domains/DNS, HTTPS, Firebase Auth authorized domains, redirects and exact CORS origins at deployment. Do not claim the production subdomains are live until verified.
- Never put Razorpay secrets in prompt text, frontend code, source files or GitHub. Use server-side secrets only.
